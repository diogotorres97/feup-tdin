Group elements:

Diogo Luis Rey Torres - 201506428 - up201506428@fe.up.pt
Rui Emanuel Cabral de Almeida Quaresma - 201503005 - up201503005@fe.up.pt


Deployment - Using Rider provided by JetBrains on Release Mode.

Use Instructions -Start by running the server.exe and then executing all the existing Apps ( BarKitchen.exe, DiningRoom.exe, Payment.exe, Logger.exe, Printer.exe and Statistics.exe). 

For more information, please read the report on docs folder.
