public class LoggerController : AbstractController
{
    public LoggerController() : base("Logger.exe.config")
    {
    }
}