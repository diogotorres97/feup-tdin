const emailServer = require('./server');

module.exports = {
  emailServer,
};
