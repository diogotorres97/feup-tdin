const configs = {
    SERVER_HOST: 'http://localhost/api/store',
};

module.exports = {configs};
