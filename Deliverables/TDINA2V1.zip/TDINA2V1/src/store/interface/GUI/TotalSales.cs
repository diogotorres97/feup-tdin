﻿namespace @interface
{
    class TotalSales
    {
        public string totalSales { get; set; }

        public TotalSales(string totalSales)
        {
            this.totalSales = totalSales;
        }
    }
}