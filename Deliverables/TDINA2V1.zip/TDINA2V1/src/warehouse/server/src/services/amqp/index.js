const amqpAPI = require('./api');
const amqpServer = require('./server');

module.exports = {
  amqpAPI,
  amqpServer,
};
