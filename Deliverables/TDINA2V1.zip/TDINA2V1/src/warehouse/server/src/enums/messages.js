const messageType = {
  requestStock: 'request_stock',
  receiveStock: 'receive_stock',
  updateBook: 'update_book',
  createRequest: 'create_request',
  updateRequest: 'update_request',
};

module.exports = {
  messageType,
};
