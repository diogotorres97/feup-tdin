const { messageType } = require('./messages');

module.exports = {
  messageType,
};
