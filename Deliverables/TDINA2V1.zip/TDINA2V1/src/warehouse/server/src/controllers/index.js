const booksController = require('./books');
const requestsController = require('./requests');

module.exports = {
  booksController,
  requestsController,
};
