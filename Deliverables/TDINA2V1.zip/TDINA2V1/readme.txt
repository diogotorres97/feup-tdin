Group elements:

Diogo Luis Rey Torres - 201506428 - up201506428@fe.up.pt
Rui Emanuel Cabral de Almeida Quaresma - 201503005 - up201503005@fe.up.pt


Deployment and Use Instructions:

1.Setup Project
Installing Docker and Docker Compose
Before starting you'll need to have Docker and Docker Compose installed on your PC. The official instructions are in Install Docker and in Install Docker Compose.

Note: If you are getting permission error on the docker run hello-world or if you get a warning ".docker/config.json: permission denied run..." follow these instructions.

2. Use Instructions
2.1To start the environment :
$ docker-compose up

    Note: To interact with the containers see docker-compose.yml and what ports are exposed and see also the configs/nginx.conf.

2.2 Use GUIs
    Run the executable files accordingly the store or warehouse GUI.

For more information, please read the report on docs folder.
